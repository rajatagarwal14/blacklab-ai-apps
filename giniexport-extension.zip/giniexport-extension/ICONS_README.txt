⚠️ ICON FILES NEEDED
===================

Please create three icon files with these names:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)  
- icon128.png (128x128 pixels)

You can:
1. Use any image editor (Photoshop, Canva, etc.)
2. Create a simple logo with "G" or "GiniExport"
3. Use the target emoji 🎯 as inspiration
4. Suggested colors: Purple gradient (#667eea to #764ba2)

OR use online tools:
- https://www.favicon-generator.org/
- https://www.canva.com/ (create 128x128, then resize)
- Take a screenshot of the 🎯 emoji and resize it

Once created, place all three icon files in this folder.
The extension will work without icons, but it won't have a proper logo in the browser.
